from Unit import Unit


class Ratio(Unit):
    def __init__(self, id: int, name="Ratio"):
        super().__init__(id, name)
