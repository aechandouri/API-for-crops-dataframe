from Unit import Unit


class Volume(Unit):
    def __init__(self, id: int, name="Volume"):
        super().__init__(id, name)
