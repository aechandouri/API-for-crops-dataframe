from Unit import Unit

class Price(Unit):
    def __init__(self, id: int, name = "Price"):
        super().__init__(id, name)